/*
Name: Sagar Joshi(N0774756)
Project Title : Sort Analysis Toolkit.
*/

#include "SortAlgorithm.h";


//constructor of the class
SortAlgorithm::SortAlgorithm()
{
	//Constructor is called when an object of the class
	//is created
}

//destructor of the class
SortAlgorithm::~SortAlgorithm()
{
	//Destructor releases the memory and is called at the end
}


//Bubble-sort is a simple sorting algorithm that repeatedly steps 
//through the list to be sorted, compares each pair of adjacent items 
//and swaps them if they are in the wrong order
void SortAlgorithm::bubbleSort(int myArray[], int arrSize)
{
	int tmp;
	for (int i = 0; i<arrSize; i++)
	{
		for (int j = arrSize - 1; j>i; j--)
		{
			if (myArray[j]<myArray[j - 1])
			{
				tmp = myArray[j - 1];
				myArray[j - 1] = myArray[j];
				myArray[j] = tmp;
			}
		}
	}
}

//Insertion Sort works by taking each element
//and inserting it into its correct spot.

void SortAlgorithm::insertionSort(int myArray[], int arrSize)
{
	for (int j = 1; j<arrSize; j++)
	{
		int keyVal = myArray[j];
		int i = j - 1;
		while (i>-1 && myArray[i]>keyVal)
		{
			myArray[i + 1] = myArray[i];
			i = i - 1;
		}
		myArray[i + 1] = keyVal;

	}
}


//Merge sort divides the array into two smaller arrays and starts sorting them. 
//After that it merges the two sorted arrays. 

//Firstly this functions divides the array into two arrays. 
void SortAlgorithm::mergePart1(int myArray[], int leftMostVal, int middleVal, int rightMostVal)
{
	//n1 and n2 are the lengths two sublists.
	//We find this so we know how long our two arrays need to be.
	int n1 = middleVal - leftMostVal + 1;
	int n2 = rightMostVal - middleVal;

	//The two lengths, help create two arrays which are divided from the main array. 
	int* leftList = new int[(middleVal - leftMostVal + 1) + 1];
	int* rightList = new int[(rightMostVal - middleVal) + 1];
	for (int i = 0; i<(middleVal - leftMostVal + 1); i++)
	{
		leftList[i] = myArray[leftMostVal + i];
	}
	for (int j = 0; j<(rightMostVal - middleVal); j++)
	{
		rightList[j] = myArray[middleVal + 1 + j];
	}


	//Create a large value for example, infinity, which is bigger than
	// the largest element in the array. 
	//This will help the code identify that the array has been sorted and
	//all integers in the array are sorted. 
	int largestVal;
	if (leftList[n1 - 1] < rightList[n2 - 1])
	{
		largestVal = rightList[n2 - 1];
	}
	else
	{
		largestVal = leftList[n1 - 1];
	}
	leftList[n1] = largestVal + 1;
	rightList[n2] = largestVal + 1;

	//This uses both lists Left list and right list
	//Elements in the Left and Right lists are compared
	//They are stored in the orignal list[], with the help of 
	//the pointer s. 
	//They are compared until both lists L and R are sorted
	//After that L and R are deleted as the orignal list is sorted.
	int i = 0;
	int j = 0;
	for (int s = leftMostVal; s <= rightMostVal; s++)
	{
		if (leftList[i] <= rightList[j])
		{
			myArray[s] = leftList[i];
			i++;
		}
		else
		{
			myArray[s] = rightList[j];
			j++;
		}
	}
	delete[] leftList;
	delete[] rightList;
}

//P is the left most value, 
//R is the right most value, 
//q is the point where the array is separated. 
//These values are used in order to make the two arrays and sorting them. 
//The process is then repeated until the array is sorted. 
void SortAlgorithm::mergePart2(int myArray[], int leftMostVal, int rightMostVal)
{
	if (leftMostVal < rightMostVal)
	{
		int middleVal = floor((leftMostVal + rightMostVal) / 2);
		mergePart2(myArray, leftMostVal, middleVal);
		mergePart2(myArray, middleVal + 1, rightMostVal);
		mergePart1(myArray, leftMostVal, middleVal, rightMostVal);
	}
}


//This helps identify if the list is sorted,
//Once its sorted its implemented into the main list[]
void SortAlgorithm::mergeSort(int myArray[], int arrSize)
{
	mergePart2(myArray, 0, arrSize - 1);
}

//Quicksort works by partitioning the array based on a 'pivotVal' element, everything
//to the right of it are greater than or equal to the pivot, everything 
//smaller than the pivot are moved to the left. 
//Then this is repeated until the array is sorted. 

//Following sort code sourced from
//https://codereview.stackexchange.com/questions/77782/quick-sort-implementation
//However, the actual code has not been copied, but idea has been taken from the website

int SortAlgorithm::partition(int myArray[], int leftMostVal, int rightMostVal)
{
	int tmpExchange, pivotVal, indexVal;
	pivotVal = myArray[rightMostVal];
	indexVal = leftMostVal - 1;
	for (int i = leftMostVal; i < rightMostVal; i++)
	{
		if (myArray[i] <= pivotVal)
		{
			indexVal++;
			tmpExchange = myArray[i];
			myArray[i] = myArray[indexVal];
			myArray[indexVal] = tmpExchange;
		}
	}
	tmpExchange = myArray[rightMostVal];
	myArray[rightMostVal] = myArray[indexVal + 1];
	myArray[indexVal + 1] = tmpExchange;
	return indexVal + 1;
}

//Once the pivot value is sorted into its right place.
//A new pivot value is set and then the partition function repeats.
//This happens until the whole array is set. 
void SortAlgorithm::quickSortPart2(int myArray[], int leftMostVal, int rightMostVal)
{
	int middleVal;
	if (leftMostVal<rightMostVal)
	{
		middleVal = partition(myArray, leftMostVal, rightMostVal);
		quickSortPart2(myArray, leftMostVal, middleVal - 1);
		quickSortPart2(myArray, middleVal + 1, rightMostVal);
	}
}

//Once the array is sorted,
//The code below tests to make sure that it is sorted. 
void SortAlgorithm::quickSort(int myArray[], int arrSize)
{
	quickSortPart2(myArray, 0, arrSize - 1);
}

// end of code sourced from 
//https://codereview.stackexchange.com/questions/77782/quick-sort-implementation
//However, the actual code has not been copied, but idea has been taken from the website