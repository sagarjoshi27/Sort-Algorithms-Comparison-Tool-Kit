/*
Name: Sagar Joshi(N0774756)
Project Title : Sort Analysis Toolkit.
*/

#include <iostream>
#include <math.h>
#include <chrono>
#include <ctime> // to add date time in file name
#include "SortAlgorithm.h"

using std::cout;
using std::endl;

//Following sort code sourced from 
//https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis

//#ifdef _MSC_VER
//#define _CRT_SECURE_NO_WARNINGS
//#endif

// end of code sourced from 
//https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis

int main()
{
	//Created an object from the SortAlgorithm class.
	SortAlgorithm SAObj;

	//Following sort code sourced from	
	//https://www.programiz.com/cpp-programming/examples/time-structure
	//However, the actual code has not been copied, but idea has been taken from the website

	//This compares the timing of the four different sorting algorithms.
	std::chrono::high_resolution_clock::time_point t1, t2;
	srand((unsigned)time(0));

	int noOfMaxElementsInArray = 100000, hundred = 100;
	const int npoints = 28;
	double  listTimeBubble[npoints], listTimeInsertion[npoints], listTimeMerge[npoints], listTimeQuick[npoints];
	int npointsi_arr[npoints];

	int *arrlist1 = new int[noOfMaxElementsInArray];
	int *arrlist2 = new int[noOfMaxElementsInArray];
	int *arrlist3 = new int[noOfMaxElementsInArray];
	int *arrlist4 = new int[noOfMaxElementsInArray];

	//This will take a number of elements from a list (nplist)
	//Which will then be used to sort the random arrays. 
	// The array size will also be averaged over 100 instances. 

	double nplist[npoints];
	nplist[0] = 1;
	for (int n = 0; n < 5; n++)
	{
		for (int j = 2; j < 11; j++)
		{
			if ((9 * n + j - 1) <= 27) {
				nplist[9 * n + j - 1] = j * pow(10, n);
				//cout << "nplist : " << (9 * n + j - 1) << " , " << (j * pow(10, n)) << endl;
			}
		}
	}

	int icounter = 0;

	//cout << "Number of random points being sorted:\n";

	for (int npointsi : nplist)
	{
		//cout << "npointsi values in for loop : " << npointsi << endl;

		//bubbleTime, insertionTime, mergeTime are the times for an individual run for each sort algorithm
		//The times are then added to the timers, e.g. bubbleTempTimer and so on
		//The times are added over the 100 instances and then the average is found by dividing this
		//number by 100 which is stored as variable hundred.
		//it is then added to the time lists e.g. listTimeBubble and so on

		double bubbleTime, insertionTime, mergeTime, quickTime;
		double bubbleTempTimer = 0.0;
		double insertionTempTimer = 0.0;
		double mergeTempTimer = 0.0;
		double quickTempTimer = 0.0;

		for (int j = 0; j < hundred; j++)
		{
			//cout <<"hundred = "<<hundred << endl;
			//cout << "npointsi = " << npointsi << endl;
			//cout <<"npintsi"<<j<<"  = "<< npointsi << endl;

			//this loop generates a random array four times for each sort algorithm.
			for (int ii = 0; ii < npointsi; ii++)
			{
				arrlist1[ii] = arrlist2[ii] = arrlist3[ii] = arrlist4[ii] = rand() % 100;

			}

			//This helps find dthe time taken in microseconds for each algorithm.
			//In this case Merge and Quick sort.

			t1 = std::chrono::high_resolution_clock::now();
			SAObj.mergeSort(arrlist1, npointsi);
			t2 = std::chrono::high_resolution_clock::now();
			mergeTime = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
			mergeTempTimer += mergeTime;


			t1 = std::chrono::high_resolution_clock::now();
			SAObj.quickSort(arrlist2, npointsi);
			t2 = std::chrono::high_resolution_clock::now();
			quickTime = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
			quickTempTimer += quickTime;

			/*
			t1 = std::chrono::high_resolution_clock::now();
			SAObj.bubble_sort(arrlist3, npointsi);
			t2 = std::chrono::high_resolution_clock::now();
			bubbleTime = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
			bubbleTempTimer += bubbleTime;

			t1 = std::chrono::high_resolution_clock::now();
			SAObj.insertion_sort(arrlist4, npointsi);
			t2 = std::chrono::high_resolution_clock::now();
			insertionTime = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
			insertionTempTimer += insertionTime;
			*/


			//Bubble and Insertion sort are two algorithms which works perfectly for small datasets.
			//However, if there are more than 500 items to sort its not efficient.
			//As it takes a lot of memory. This is tested through the commented code above. 

			//This helps find dthe time taken in microseconds for each algorithm.
			//In this case Insertion and Bubble sort.

			if (npointsi <= 500)
			{
				t1 = std::chrono::high_resolution_clock::now();
				SAObj.bubbleSort(arrlist3, npointsi);
				t2 = std::chrono::high_resolution_clock::now();
				bubbleTime = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
				bubbleTempTimer += bubbleTime;

				t1 = std::chrono::high_resolution_clock::now();
				SAObj.insertionSort(arrlist4, npointsi);
				t2 = std::chrono::high_resolution_clock::now();
				insertionTime = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
				insertionTempTimer += insertionTime;
			}
			else
			{
				bubbleTempTimer = 0.0;
				insertionTempTimer = 0.0;
			}

		}

		npointsi_arr[icounter] = npointsi;
		listTimeMerge[icounter] = mergeTempTimer / 100;
		listTimeQuick[icounter] = quickTempTimer / 100;
		listTimeInsertion[icounter] = insertionTempTimer / 100;
		listTimeBubble[icounter] = bubbleTempTimer / 100;
		icounter++;

	}
	//End of sort code sourced from	
	//https://www.programiz.com/cpp-programming/examples/time-structure
	//However, the actual code has not been copied, but idea has been taken from the website

	//Following sort code sourced from	
	//https://stackoverflow.com/questions/15063396/getting-the-time-as-file-name
	//However, the actual code has not been copied, but idea has been taken from the website

	//Add date and time in file name to generate unique file name each time
	std::time_t now = std::time(NULL);
	std::tm * ptm = std::localtime(&now);
	char buffer[64];
	// Format: 15_06_2009_20_20_00
	std::strftime(buffer, 64, "Sort_Analysis_%d_%m_%Y_%H_%M_%S.csv", ptm);
	cout << buffer << " file created." << endl;

	//End of sort code sourced from	
	//https://stackoverflow.com/questions/15063396/getting-the-time-as-file-name
	//However, the actual code has not been copied, but idea has been taken from the website

	//Generates a .CSV file, from which a graph can be created for further analysis in excel. 
	FILE * resultsfile;

	//resultsfile = fopen("Sort Analysis.csv", "w");
	resultsfile = fopen(buffer, "w");

	//add column headings in file
	fprintf(resultsfile, "%s,%s,%s,%s,%s\n", "", "bubble", "insertion", "merge", "quick");

	//Add data into file
	for (int j = 0; j < npoints; j++)
	{
		fprintf(resultsfile, "%d,%10.2f,%10.2f,%10.2f,%10.2f \n", npointsi_arr[j], listTimeBubble[j], listTimeInsertion[j], listTimeMerge[j], listTimeQuick[j]);
	}

	fclose(resultsfile);

	system("pause");

}

