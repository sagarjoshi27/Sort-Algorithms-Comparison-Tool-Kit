/*
Name: Sagar Joshi(N0774756)
Project Title : Sort Analysis Toolkit.
*/

#pragma once
#include <iostream>
#include <math.h>
#include <chrono>

//Following sort code sourced from 
//https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis

//#ifdef _MSC_VER
//#define _CRT_SECURE_NO_WARNINGS
//#endif

// end of code sourced from 
//https://stackoverflow.com/questions/16883037/remove-secure-warnings-crt-secure-no-warnings-from-projects-by-default-in-vis

using std::cout;
using std::endl;

#ifndef SortAlgorithm_h
#define SortAlgorithm_h
#endif

//Class for Sort Algorithms
class SortAlgorithm
{
	//set public methods which are to be used in main.cpp
public:
	SortAlgorithm();
	~SortAlgorithm();
	void mergePart1(int*, int, int, int);
	void mergePart2(int*, int, int);
	int partition(int*, int, int);
	void quickSortPart2(int*, int, int);

	void bubbleSort(int*, int);
	void insertionSort(int*, int);
	void mergeSort(int*, int);
	void quickSort(int*, int);



};

